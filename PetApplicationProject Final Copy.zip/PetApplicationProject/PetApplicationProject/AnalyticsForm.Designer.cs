﻿namespace PetApplicationProject
{
    partial class AnalyticsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            label1 = new Label();
            btnBack = new Button();
            chartPets = new System.Windows.Forms.DataVisualization.Charting.Chart();
            dgvPets = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)chartPets).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvPets).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(350, 49);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(243, 48);
            label1.TabIndex = 7;
            label1.Text = "Data Analytics";
            // 
            // btnBack
            // 
            btnBack.Location = new Point(647, 412);
            btnBack.Margin = new Padding(4);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(189, 51);
            btnBack.TabIndex = 6;
            btnBack.Text = "Back";
            btnBack.UseVisualStyleBackColor = true;
            btnBack.Click += btnBack_Click_1;
            // 
            // chartPets
            // 
            chartArea2.Name = "ChartArea1";
            chartPets.ChartAreas.Add(chartArea2);
            legend2.Name = "Legend1";
            chartPets.Legends.Add(legend2);
            chartPets.Location = new Point(46, 120);
            chartPets.Margin = new Padding(4);
            chartPets.Name = "chartPets";
            chartPets.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Berry;
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pie;
            series2.Legend = "Legend1";
            series2.Name = "Series1";
            chartPets.Series.Add(series2);
            chartPets.Size = new Size(395, 272);
            chartPets.TabIndex = 5;
            chartPets.Text = "chartPets";
            // 
            // dgvPets
            // 
            dgvPets.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvPets.Location = new Point(523, 120);
            dgvPets.Margin = new Padding(4);
            dgvPets.Name = "dgvPets";
            dgvPets.RowHeadersWidth = 51;
            dgvPets.Size = new Size(431, 272);
            dgvPets.TabIndex = 4;
            // 
            // AnalyticsForm
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(1000, 562);
            Controls.Add(label1);
            Controls.Add(btnBack);
            Controls.Add(chartPets);
            Controls.Add(dgvPets);
            Margin = new Padding(4);
            Name = "AnalyticsForm";
            Text = "AnalyticsForm";
            ((System.ComponentModel.ISupportInitialize)chartPets).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvPets).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Button btnBack;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartPets;
        private DataGridView dgvPets;
    }
}