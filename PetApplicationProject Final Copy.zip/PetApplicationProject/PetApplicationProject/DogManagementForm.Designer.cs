﻿namespace PetApplicationProject
{
    partial class DogManagementForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnDelete = new Button();
            btnModify = new Button();
            dgvPets = new DataGridView();
            txtName = new TextBox();
            txtBreed = new TextBox();
            txtAge = new TextBox();
            chkMale = new CheckBox();
            chkFemale = new CheckBox();
            cmbSize = new ComboBox();
            txtDescription = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            groupBox1 = new GroupBox();
            btnAdd = new Button();
            label6 = new Label();
            btnBack = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvPets).BeginInit();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // btnDelete
            // 
            btnDelete.Location = new Point(414, 462);
            btnDelete.Margin = new Padding(4, 3, 4, 3);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(117, 37);
            btnDelete.TabIndex = 0;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += btnDelete_Click;
            // 
            // btnModify
            // 
            btnModify.Location = new Point(716, 462);
            btnModify.Margin = new Padding(4, 3, 4, 3);
            btnModify.Name = "btnModify";
            btnModify.Size = new Size(117, 37);
            btnModify.TabIndex = 1;
            btnModify.Text = "Modify";
            btnModify.UseVisualStyleBackColor = true;
            btnModify.Click += btnModify_Click;
            // 
            // dgvPets
            // 
            dgvPets.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvPets.Location = new Point(431, 100);
            dgvPets.Margin = new Padding(4, 3, 4, 3);
            dgvPets.Name = "dgvPets";
            dgvPets.RowHeadersWidth = 51;
            dgvPets.Size = new Size(461, 313);
            dgvPets.TabIndex = 2;
            // 
            // txtName
            // 
            txtName.Location = new Point(146, 100);
            txtName.Margin = new Padding(4, 3, 4, 3);
            txtName.Name = "txtName";
            txtName.Size = new Size(155, 31);
            txtName.TabIndex = 3;
            // 
            // txtBreed
            // 
            txtBreed.Location = new Point(146, 170);
            txtBreed.Margin = new Padding(4, 3, 4, 3);
            txtBreed.Name = "txtBreed";
            txtBreed.Size = new Size(155, 31);
            txtBreed.TabIndex = 4;
            // 
            // txtAge
            // 
            txtAge.Location = new Point(146, 245);
            txtAge.Margin = new Padding(4, 3, 4, 3);
            txtAge.Name = "txtAge";
            txtAge.Size = new Size(155, 31);
            txtAge.TabIndex = 5;
            // 
            // chkMale
            // 
            chkMale.AutoSize = true;
            chkMale.Location = new Point(7, 33);
            chkMale.Margin = new Padding(4, 3, 4, 3);
            chkMale.Name = "chkMale";
            chkMale.Size = new Size(76, 29);
            chkMale.TabIndex = 6;
            chkMale.Text = "Male";
            chkMale.UseVisualStyleBackColor = true;
            // 
            // chkFemale
            // 
            chkFemale.AutoSize = true;
            chkFemale.Location = new Point(7, 70);
            chkFemale.Margin = new Padding(4, 3, 4, 3);
            chkFemale.Name = "chkFemale";
            chkFemale.Size = new Size(94, 29);
            chkFemale.TabIndex = 7;
            chkFemale.Text = "Female";
            chkFemale.UseVisualStyleBackColor = true;
            // 
            // cmbSize
            // 
            cmbSize.FormattingEnabled = true;
            cmbSize.Location = new Point(146, 422);
            cmbSize.Margin = new Padding(4, 3, 4, 3);
            cmbSize.Name = "cmbSize";
            cmbSize.Size = new Size(188, 33);
            cmbSize.TabIndex = 8;
            // 
            // txtDescription
            // 
            txtDescription.Location = new Point(146, 488);
            txtDescription.Margin = new Padding(4, 3, 4, 3);
            txtDescription.Name = "txtDescription";
            txtDescription.Size = new Size(188, 31);
            txtDescription.TabIndex = 9;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(43, 108);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(63, 25);
            label1.TabIndex = 10;
            label1.Text = "Name:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(43, 178);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(61, 25);
            label2.TabIndex = 11;
            label2.Text = "Breed:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(41, 253);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(48, 25);
            label3.TabIndex = 12;
            label3.Text = "Age:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(41, 432);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(47, 25);
            label4.TabIndex = 13;
            label4.Text = "Size:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(41, 493);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(106, 25);
            label5.TabIndex = 14;
            label5.Text = "Description:";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(chkFemale);
            groupBox1.Controls.Add(chkMale);
            groupBox1.Location = new Point(146, 312);
            groupBox1.Margin = new Padding(4, 3, 4, 3);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(4, 3, 4, 3);
            groupBox1.Size = new Size(127, 103);
            groupBox1.TabIndex = 15;
            groupBox1.TabStop = false;
            groupBox1.Text = "Gender";
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(564, 462);
            btnAdd.Margin = new Padding(4, 3, 4, 3);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(117, 37);
            btnAdd.TabIndex = 16;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 24F);
            label6.Location = new Point(284, 15);
            label6.Margin = new Padding(4, 0, 4, 0);
            label6.Name = "label6";
            label6.Size = new Size(411, 65);
            label6.TabIndex = 17;
            label6.Text = "Dog Management";
            // 
            // btnBack
            // 
            btnBack.Location = new Point(861, 463);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(112, 34);
            btnBack.TabIndex = 18;
            btnBack.Text = "Back";
            btnBack.UseVisualStyleBackColor = true;
            btnBack.Click += btnBack_Click;
            // 
            // DogManagementForm
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(1000, 563);
            Controls.Add(btnBack);
            Controls.Add(label6);
            Controls.Add(btnAdd);
            Controls.Add(groupBox1);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtDescription);
            Controls.Add(cmbSize);
            Controls.Add(txtAge);
            Controls.Add(txtBreed);
            Controls.Add(txtName);
            Controls.Add(dgvPets);
            Controls.Add(btnModify);
            Controls.Add(btnDelete);
            Margin = new Padding(4, 3, 4, 3);
            Name = "DogManagementForm";
            Text = "DogManagementForm";
            ((System.ComponentModel.ISupportInitialize)dgvPets).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnDelete;
        private Button btnModify;
        private DataGridView dgvPets;
        private TextBox txtName;
        private TextBox txtBreed;
        private TextBox txtAge;
        private CheckBox chkMale;
        private CheckBox chkFemale;
        private ComboBox cbSize;
        private TextBox txtDescription;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private GroupBox groupBox1;
        private Button btnAdd;
        private ComboBox cmbSize;
        private Label label6;
        private Button btnBack;
    }
}