﻿namespace PetApplicationProject
{
    partial class RegistrationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtFirstName = new TextBox();
            txtLastName = new TextBox();
            txtEmail = new TextBox();
            label1 = new Label();
            txtPassword = new TextBox();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label8 = new Label();
            label9 = new Label();
            txtAddress = new TextBox();
            txtPhone = new TextBox();
            btnRegister = new Button();
            btnClear = new Button();
            label10 = new Label();
            txtUsername = new TextBox();
            rbCustomer = new RadioButton();
            rbEmployee = new RadioButton();
            label6 = new Label();
            SuspendLayout();
            // 
            // txtFirstName
            // 
            txtFirstName.Location = new Point(259, 131);
            txtFirstName.Margin = new Padding(4);
            txtFirstName.Name = "txtFirstName";
            txtFirstName.Size = new Size(155, 31);
            txtFirstName.TabIndex = 0;
            // 
            // txtLastName
            // 
            txtLastName.Location = new Point(259, 190);
            txtLastName.Margin = new Padding(4);
            txtLastName.Name = "txtLastName";
            txtLastName.Size = new Size(155, 31);
            txtLastName.TabIndex = 1;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(259, 316);
            txtEmail.Margin = new Padding(4);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(155, 31);
            txtEmail.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Showcard Gothic", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(284, 39);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(399, 42);
            label1.TabIndex = 3;
            label1.Text = "Happy Tails Adoption";
            // 
            // txtPassword
            // 
            txtPassword.Location = new Point(259, 380);
            txtPassword.Margin = new Padding(4);
            txtPassword.Name = "txtPassword";
            txtPassword.Size = new Size(155, 31);
            txtPassword.TabIndex = 4;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(131, 135);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(101, 25);
            label2.TabIndex = 6;
            label2.Text = "First Name:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(131, 194);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(99, 25);
            label3.TabIndex = 7;
            label3.Text = "Last Name:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(131, 320);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(63, 25);
            label4.TabIndex = 8;
            label4.Text = "Email: ";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(100, 384);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(131, 25);
            label5.TabIndex = 9;
            label5.Text = "New Password:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(519, 196);
            label8.Margin = new Padding(4, 0, 4, 0);
            label8.Name = "label8";
            label8.Size = new Size(81, 25);
            label8.TabIndex = 15;
            label8.Text = "Address:";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(461, 135);
            label9.Margin = new Padding(4, 0, 4, 0);
            label9.Name = "label9";
            label9.Size = new Size(136, 25);
            label9.TabIndex = 14;
            label9.Text = "Phone Number:";
            // 
            // txtAddress
            // 
            txtAddress.Location = new Point(626, 194);
            txtAddress.Margin = new Padding(4);
            txtAddress.Name = "txtAddress";
            txtAddress.Size = new Size(155, 31);
            txtAddress.TabIndex = 12;
            // 
            // txtPhone
            // 
            txtPhone.Location = new Point(626, 135);
            txtPhone.Margin = new Padding(4);
            txtPhone.Name = "txtPhone";
            txtPhone.Size = new Size(155, 31);
            txtPhone.TabIndex = 11;
            // 
            // btnRegister
            // 
            btnRegister.Location = new Point(549, 333);
            btnRegister.Margin = new Padding(4);
            btnRegister.Name = "btnRegister";
            btnRegister.Size = new Size(118, 36);
            btnRegister.TabIndex = 20;
            btnRegister.Text = "Register";
            btnRegister.UseVisualStyleBackColor = true;
            btnRegister.Click += btnRegister_Click;
            // 
            // btnClear
            // 
            btnClear.Location = new Point(674, 333);
            btnClear.Margin = new Padding(4);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(118, 36);
            btnClear.TabIndex = 21;
            btnClear.Text = "Clear";
            btnClear.UseVisualStyleBackColor = true;
            btnClear.Click += btnClear_Click;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(131, 256);
            label10.Margin = new Padding(4, 0, 4, 0);
            label10.Name = "label10";
            label10.Size = new Size(98, 25);
            label10.TabIndex = 23;
            label10.Text = "UserName:";
            // 
            // txtUsername
            // 
            txtUsername.Location = new Point(259, 254);
            txtUsername.Margin = new Padding(4);
            txtUsername.Name = "txtUsername";
            txtUsername.Size = new Size(155, 31);
            txtUsername.TabIndex = 22;
            // 
            // rbCustomer
            // 
            rbCustomer.AutoSize = true;
            rbCustomer.Location = new Point(626, 252);
            rbCustomer.Margin = new Padding(4);
            rbCustomer.Name = "rbCustomer";
            rbCustomer.Size = new Size(114, 29);
            rbCustomer.TabIndex = 25;
            rbCustomer.TabStop = true;
            rbCustomer.Text = "Customer";
            rbCustomer.UseVisualStyleBackColor = true;
            // 
            // rbEmployee
            // 
            rbEmployee.AutoSize = true;
            rbEmployee.Location = new Point(626, 296);
            rbEmployee.Margin = new Padding(4);
            rbEmployee.Name = "rbEmployee";
            rbEmployee.Size = new Size(115, 29);
            rbEmployee.TabIndex = 26;
            rbEmployee.TabStop = true;
            rbEmployee.Text = "Employee";
            rbEmployee.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(547, 252);
            label6.Margin = new Padding(4, 0, 4, 0);
            label6.Name = "label6";
            label6.Size = new Size(50, 25);
            label6.TabIndex = 27;
            label6.Text = "Role:";
            // 
            // RegistrationForm
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(949, 564);
            Controls.Add(label6);
            Controls.Add(rbEmployee);
            Controls.Add(rbCustomer);
            Controls.Add(label10);
            Controls.Add(txtUsername);
            Controls.Add(btnClear);
            Controls.Add(btnRegister);
            Controls.Add(label8);
            Controls.Add(label9);
            Controls.Add(txtAddress);
            Controls.Add(txtPhone);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(txtPassword);
            Controls.Add(label1);
            Controls.Add(txtEmail);
            Controls.Add(txtLastName);
            Controls.Add(txtFirstName);
            Margin = new Padding(4);
            Name = "RegistrationForm";
            Text = "RegistrationForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtFirstName;
        private TextBox txtLastName;
        private TextBox txtEmail;
        private Label label1;
        private TextBox txtPassword;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label8;
        private Label label9;
        private TextBox txtAddress;
        private TextBox txtPhone;
        private Button btnRegister;
        private Button btnClear;
        private Label label10;
        private TextBox txtUsername;
        private RadioButton rbCustomer;
        private RadioButton rbEmployee;
        private Label label6;
    }
}