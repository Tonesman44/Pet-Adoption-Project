﻿using System;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace PetApplicationProject
{
    public partial class AdoptionApplicationForm : Form
    {
        private string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0; Data Source=PetApplicationDB.accdb";
        private int loggedInUserId;
        private int roleID;
        private string userName;
        private DataTable dogsTable;

        public AdoptionApplicationForm(string userName, int roleID, int userId)
        {
            InitializeComponent();
            this.userName = userName;
            this.roleID = roleID;
            loggedInUserId = userId;
            lblUserID.Text = $"User ID: {loggedInUserId}";
            LoadDogSelection();
            cmbStatus.SelectedItem = "Pending"; 
        }

        private void LoadDogSelection()
        {
            string query = @"
            SELECT Dogs.DogID, Dogs.Name
            FROM Dogs
            LEFT JOIN [Adoption Application] 
            ON Dogs.DogID = [Adoption Application].DogID
            WHERE [Adoption Application].Status IS NULL 
            OR [Adoption Application].Status <> 'Approved'";

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    using (OleDbDataAdapter adapter = new OleDbDataAdapter(query, conn))
                    {
                        dogsTable = new DataTable();
                        adapter.Fill(dogsTable);

                        foreach (DataRow row in dogsTable.Rows)
                        {
                            cmbDogSelection.Items.Add(row["Name"].ToString());
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error loading dogs: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (cmbDogSelection.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a dog.", "Missing Information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!ValidateForm())
            {
                MessageBox.Show("Please complete all required fields.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string selectedDogName = cmbDogSelection.SelectedItem.ToString();
            DataRow selectedDogRow = dogsTable.Select($"Name = '{selectedDogName.Replace("'", "''")}'")[0];
            int dogId = Convert.ToInt32(selectedDogRow["DogID"]);
            string status = "Pending"; 
            DateTime applicationDate = DateTime.Now;

            string query = @"
            INSERT INTO [Adoption Application] 
            (UserID, DogID, Status, QuestionOwnedPets, QuestionLiving, QuestionAfterCare, QuestionChildren, QuestionAmountOfPets)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("?", loggedInUserId); 
                        cmd.Parameters.AddWithValue("?", dogId); 
                        cmd.Parameters.AddWithValue("?", status); 
                        cmd.Parameters.AddWithValue("?", GetYesNoValue(groupPets)); 
                        cmd.Parameters.AddWithValue("?", GetYesNoValue(groupStable)); 
                        cmd.Parameters.AddWithValue("?", txtAfterCare.Text.Trim()); 
                        cmd.Parameters.AddWithValue("?", GetYesNoValue(groupChildren));
                        cmd.Parameters.AddWithValue("?", Convert.ToInt32(nudAmountPets.Value));

                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Adoption application submitted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Close();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error submitting application: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private bool GetYesNoValue(GroupBox groupBox)
        {
            foreach (Control control in groupBox.Controls)
            {
                if (control is RadioButton radioButton && radioButton.Checked)
                {
                    return radioButton.Text.ToLower() == "yes";
                }
            }
            throw new Exception("Yes/No value not selected for a question.");
        }

        private bool ValidateForm()
        {
            if (cmbDogSelection.SelectedIndex == -1 ||
                string.IsNullOrWhiteSpace(txtAfterCare.Text) ||
                nudAmountPets.Value < 0 ||
                !IsRadioButtonGroupValid(groupPets) ||
                !IsRadioButtonGroupValid(groupStable) ||
                !IsRadioButtonGroupValid(groupChildren))
            {
                return false;
            }
            return true;
        }

        private bool IsRadioButtonGroupValid(GroupBox groupBox)
        {
            foreach (Control control in groupBox.Controls)
            {
                if (control is RadioButton radioButton && radioButton.Checked)
                {
                    return true;
                }
            }
            return false;
        }

        private void btnCancel_Click_1(object sender, EventArgs e)
        {
            this.Close();
            DashboardForm df = new DashboardForm(userName, roleID, loggedInUserId);
            df.ShowDialog();
        }
    }
}
