﻿using System;
using System.Data;
using System.Data.OleDb;
using System.Net.Mail;
using System.Net;
using System.Windows.Forms;
using SendGrid;
using SendGrid.Helpers.Mail;
using System.Threading.Tasks;

namespace PetApplicationProject
{
    public partial class AdminPanelForm : Form
    {
        private string userName;
        private int roleId;
        private int loggedInUserId;

        string myDatabase = "Provider=Microsoft.ACE.OLEDB.12.0; Data Source = PetApplicationDB.accdb";
        DataTable applicationsTable;

        private System.Timers.Timer emailReminderTimer;
        private int daysElapsed = 0;

        public AdminPanelForm(string userName, int roleID, int loggedInUserId)
        {
            InitializeComponent();
            LoadData();
            this.loggedInUserId = loggedInUserId;
            this.userName = userName;
            this.roleId = roleID;

            emailReminderTimer = new System.Timers.Timer();
            emailReminderTimer.Interval = TimeSpan.FromDays(1).TotalMilliseconds;
            emailReminderTimer.Elapsed += CheckReminderCondition;
            emailReminderTimer.AutoReset = true;
            emailReminderTimer.Start();
        }

        private void CheckReminderCondition(object sender, System.Timers.ElapsedEventArgs e)
        {
            daysElapsed++;
            if (daysElapsed >= 30)
            {
                daysElapsed = 0;
                SendPeriodicCheckupEmails();
            }
        }

        private async void SendPeriodicCheckupEmails()
        {
            try
            {
                string query = "SELECT u.Email, u.FirstName FROM [Users] u WHERE u.ApplicationStatus = 'Pending'";

                using (OleDbConnection conn = new OleDbConnection(myDatabase))
                {
                    conn.Open();

                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    {
                        using (OleDbDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                string email = reader["Email"].ToString();
                                string firstName = reader["FirstName"].ToString();

                                string subject = "Reminder: Pending Adoption Application";
                                string body = $"Dear {firstName},\n\nThis is a reminder that your adoption application is still pending. Please check back for further updates.\n\nThank you,\nPet Adoption Team";

                                await SendEmailAsync(email, subject, body);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error sending periodic emails: {ex.Message}", "Email Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void LoadData()
        {
            string query = "SELECT * FROM [Adoption Application]";

            try
            {
                using (OleDbConnection conn = new OleDbConnection(myDatabase))
                {
                    conn.Open();

                    OleDbDataAdapter adapter = new OleDbDataAdapter(query, conn);
                    applicationsTable = new DataTable();
                    adapter.Fill(applicationsTable);
                    dgvApplications.DataSource = applicationsTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error has occurred: {ex.Message}", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void PopulateFields(string userId)
        {
            try
            {
                DataRow[] rows = applicationsTable.Select($"UserID = '{userId}'");

                if (rows.Length > 0)
                {
                    DataRow row = rows[0];

                    txtQuestionOwnedPets.Text = Convert.ToBoolean(row["QuestionOwnedPets"]) ? "Yes" : "No";
                    txtQuestionLiving.Text = Convert.ToBoolean(row["QuestionLiving"]) ? "Yes" : "No";
                    txtQuestionChildren.Text = Convert.ToBoolean(row["QuestionChildren"]) ? "Yes" : "No";
                    txtQuestionAmountPets.Text = row["QuestionAmountOfPets"].ToString();
                    rtxtQuestionAfterCare.Text = row["QuestionAfterCare"].ToString();
                }
                else
                {
                    MessageBox.Show("No application found for the provided UserID.", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    ClearFields();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error has occurred: {ex.Message}", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ClearFields()
        {
            txtQuestionOwnedPets.Clear();
            txtQuestionLiving.Clear();
            txtQuestionChildren.Clear();
            txtQuestionAmountPets.Clear();
            rtxtQuestionAfterCare.Clear();
        }

        private void ApproveApplication(string userId)
        {
            string query = "UPDATE [Adoption Application] SET [Status] = 'Approved' WHERE [UserID] = ? AND [Status] = 'Pending'";

            try
            {
                using (OleDbConnection conn = new OleDbConnection(myDatabase))
                {
                    conn.Open();

                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("?", userId);
                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Application approved successfully.", "Approval", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            LoadData();
                            ClearFields();
                            SendApprovalEmail(userId);
                        }
                        else
                        {
                            MessageBox.Show("Application not found or is not in a pending state.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error has occurred: {ex.Message}", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void DenyApplication(string userId)
        {
            string query = "DELETE FROM [Adoption Application] WHERE [UserID] = ?";

            try
            {
                using (OleDbConnection conn = new OleDbConnection(myDatabase))
                {
                    conn.Open();

                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("?", userId);
                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Application denied and removed successfully.", "Denial", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            LoadData();
                            ClearFields();
                        }
                        else
                        {
                            MessageBox.Show("Application not found or could not be removed.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error has occurred: {ex.Message}", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void SendApprovalEmail(string userId)
        {
            try
            {
                string query = "SELECT u.Email, u.FirstName FROM [Users] u WHERE u.UserID = ?";

                using (OleDbConnection conn = new OleDbConnection(myDatabase))
                {
                    conn.Open();

                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("?", userId);

                        using (OleDbDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                string email = reader["Email"].ToString();
                                string firstName = reader["FirstName"].ToString();

                                string subject = "Adoption Application Approved";
                                string body = $"Dear {firstName},\n\nCongratulations! Your adoption application has been approved. Please follow up with the adoption center for further steps.\n\nThank you,\nPet Adoption Team";

                                await SendEmailAsync(email, subject, body);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error sending email: {ex.Message}", "Email Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async Task SendEmailAsync(string toEmail, string subject, string body)
        {
            try
            {
                var apiKey = "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";
                var client = new SendGridClient(apiKey);
                var from = new EmailAddress("antonioman44@gmail.com", "Happy Tails Adoption");
                var to = new EmailAddress(toEmail);
                var plainTextContent = body;
                var htmlContent = $"<strong>{body}</strong>";
                var msg = MailHelper.CreateSingleEmail(from, to, subject, plainTextContent, htmlContent);

                var response = await client.SendEmailAsync(msg);
                Console.WriteLine($"Email sent to {toEmail}, Status code: {response.StatusCode}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error sending email: {ex.Message}");
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtInput.Text))
            {
                PopulateFields(txtInput.Text.Trim());
            }
            else
            {
                MessageBox.Show("Please enter a UserID to search.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnApprove_Click_1(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtInput.Text))
            {
                ApproveApplication(txtInput.Text.Trim());
            }
            else
            {
                MessageBox.Show("Please enter a UserID to approve.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnDeny_Click_1(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtInput.Text))
            {
                DenyApplication(txtInput.Text.Trim());
            }
            else
            {
                MessageBox.Show("Please enter a UserID to deny.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            this.Close();
            DashboardForm df = new DashboardForm(userName, roleId, loggedInUserId);
            df.ShowDialog();
        }

    }
}
