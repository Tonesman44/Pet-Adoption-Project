﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace PetApplicationProject
{
    public partial class Startup : Form
    {
        string myDataBase = "Provider=Microsoft.ACE.OLEDB.12.0; Data Source = PetApplicationDB.accdb";
        public Startup()
        {
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            string query = "Select * From Users";

            using (OleDbConnection conn = new OleDbConnection(myDataBase))
            {
                try
                {
                    conn.Open();
                    OleDbDataAdapter adapter = new OleDbDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    dgvPets.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error has occured {ex.Message}");
                }
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            LoginForm form = new LoginForm();
            form.ShowDialog();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
