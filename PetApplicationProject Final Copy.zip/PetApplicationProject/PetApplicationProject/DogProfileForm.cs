﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Windows.Forms;

namespace PetApplicationProject
{
    public partial class DogProfileForm : Form
    {
        private const string DatabaseConnection = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=PetApplicationDB.accdb";
        private int userID;
        private int roleID;
        private string userName;
        public DogProfileForm(string userName, int roleID, int userID)
        {
            InitializeComponent();
            LoadDefaultDogProfile();
            this.userID = userID;
            this.roleID = roleID;
            this.userName = userName;
        }

        private void LoadDefaultDogProfile()
        {
            const string query = "SELECT TOP 1 * FROM Dogs";

            try
            {
                using (var conn = new OleDbConnection(DatabaseConnection))
                {
                    conn.Open();
                    using (var command = new OleDbCommand(query, conn))
                    using (var reader = command.ExecuteReader())
                    {
                        if (reader?.Read() == true)
                        {
                            var dog = MapReaderToDog(reader);
                            PopulateDogDetails(dog);
                        }
                        else
                        {
                            ClearDogDetails();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while loading the default dog profile: {ex.Message}", "Error");
            }
        }

        private Dog MapReaderToDog(OleDbDataReader reader)
        {
            return new Dog
            {
                Name = reader["Name"].ToString(),
                Breed = reader["Breed"].ToString(),
                Age = reader.GetInt32(reader.GetOrdinal("Age")),
                Gender = reader["Gender"].ToString(),
                Size = reader["Size"].ToString(),
                Description = reader["Description"].ToString()
            };
        }

        private void PopulateDogDetails(Dog dog)
        {
            txtName.Text = dog.Name;
            txtBreed.Text = dog.Breed;
            numAge.Value = dog.Age;
            txtGender.Text = dog.Gender;
            txtSize.Text = dog.Size;
            txtDescription.Text = dog.Description;

            DisplayImage(dog.Breed);
        }

        private void ClearDogDetails()
        {
            txtName.Clear();
            txtBreed.Clear();
            numAge.Value = 0;
            txtGender.Clear();
            txtSize.Clear();
            txtDescription.Clear();
            pictureBox1.Image = null;
        }

        private void DisplayImage(string breed)
        {
            var breedToImageMap = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
            {
                { "Cockapoo", "https://www.dailypaws.com/thmb/XPsqZiY5B3hNQN8SofRuQZW6268=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/cockapoo-red-colored-greenery-223686877-2000-08327a0071b54ddf84c7960069d56d95.jpg" },
                { "Boxer", "https://cdn.britannica.com/46/233846-050-8D30A43B/Boxer-dog.jpg" },
                { "Golden Retriever", "https://www.akc.org/wp-content/uploads/2020/07/Golden-Retriever-puppy-standing-outdoors.jpg" },
                { "Poodle", "https://upload.wikimedia.org/wikipedia/commons/thumb/f/f8/Full_attention_%288067543690%29.jpg/1200px-Full_attention_%288067543690%29.jpg" },
                { "Labrador", "https://images.wagwalkingweb.com/media/daily_wag/blog_articles/hero/1670938235.1927571/fun-facts-about-labrador-retrievers.jpg" },
                { "Chihuahua", "https://cdn.britannica.com/44/233244-050-A65D4571/Chihuahua-dog.jpg" },
                { "Beagle", "https://www.bil-jac.com/media/ambgc3os/beagle2-184102750.jpg?anchor=center&mode=crop&width=600&height=400&rnd=132167289621930000&format=webp&quality=80" },
                { "Bulldog", "https://upload.wikimedia.org/wikipedia/commons/thumb/b/bf/Bulldog_inglese.jpg/800px-Bulldog_inglese.jpg" },
                { "Pug", "https://cdn.britannica.com/34/233234-050-1649BFA9/Pug-dog.jpg" },
                { "Yorkshire Terrier", "https://cdn05.zipify.com/TNPDGbG-XijYAsfKvHkKwL8v_oc=/fit-in/3840x0/fdc57f66415e4ea8867b548377cbcb7e/1.jpeg" }
            };

            if (breedToImageMap.TryGetValue(breed, out string imageUrl))
            {
                pictureBox1.Load(imageUrl);
            }
            else
            {
                pictureBox1.Image = null;
                MessageBox.Show("No image found for the dog's breed!", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnShow_Click(object sender, EventArgs e)
        {
            string enteredName = txtName.Text.Trim();
            if (string.IsNullOrEmpty(enteredName))
            {
                MessageBox.Show("Please enter a dog's name.", "Input Error");
                return;
            }

            Dog dog = GetDogByName(enteredName);

            if (dog != null)
            {
                PopulateDogDetails(dog);
            }
            else
            {
                MessageBox.Show("No dog found with the entered name!", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ClearDogDetails();
            }
        }

        private Dog GetDogByName(string name)
        {
            Dog dog = null;
            const string query = "SELECT * FROM Dogs WHERE Name = ?";

            try
            {
                using (var conn = new OleDbConnection(DatabaseConnection))
                {
                    conn.Open();
                    using (var command = new OleDbCommand(query, conn))
                    {
                        command.Parameters.AddWithValue("@Name", name);
                        using (var reader = command.ExecuteReader())
                        {
                            if (reader?.Read() == true)
                            {
                                dog = MapReaderToDog(reader);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error");
            }

            return dog;
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
            DashboardForm dash = new DashboardForm(userName, roleID, userID);
            dash.ShowDialog();
        }
    }
}
