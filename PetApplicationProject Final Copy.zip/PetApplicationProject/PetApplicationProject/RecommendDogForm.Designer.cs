﻿namespace PetApplicationProject
{
    partial class RecommendDogForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            cmbBreed = new ComboBox();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            btnBack = new Button();
            label1 = new Label();
            pbPets = new PictureBox();
            btnRecommend = new Button();
            dgvPets = new DataGridView();
            cmbSize = new ComboBox();
            numAge = new NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)pbPets).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvPets).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numAge).BeginInit();
            SuspendLayout();
            // 
            // cmbBreed
            // 
            cmbBreed.FormattingEnabled = true;
            cmbBreed.Location = new Point(102, 152);
            cmbBreed.Margin = new Padding(4);
            cmbBreed.Name = "cmbBreed";
            cmbBreed.Size = new Size(188, 33);
            cmbBreed.TabIndex = 22;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(19, 280);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(47, 25);
            label4.TabIndex = 21;
            label4.Text = "Size:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(19, 213);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(48, 25);
            label3.TabIndex = 20;
            label3.Text = "Age:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(19, 155);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(61, 25);
            label2.TabIndex = 19;
            label2.Text = "Breed:";
            // 
            // btnBack
            // 
            btnBack.Location = new Point(200, 340);
            btnBack.Margin = new Padding(4);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(136, 54);
            btnBack.TabIndex = 18;
            btnBack.Text = "Back";
            btnBack.UseVisualStyleBackColor = true;
            btnBack.Click += btnBack_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(200, 8);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(556, 54);
            label1.TabIndex = 17;
            label1.Text = "Dog Recommendation System";
            // 
            // pbPets
            // 
            pbPets.Location = new Point(439, 383);
            pbPets.Margin = new Padding(4);
            pbPets.Name = "pbPets";
            pbPets.Size = new Size(408, 149);
            pbPets.TabIndex = 16;
            pbPets.TabStop = false;
            // 
            // btnRecommend
            // 
            btnRecommend.Location = new Point(19, 340);
            btnRecommend.Margin = new Padding(4);
            btnRecommend.Name = "btnRecommend";
            btnRecommend.Size = new Size(156, 54);
            btnRecommend.TabIndex = 15;
            btnRecommend.Text = "Recommend";
            btnRecommend.UseVisualStyleBackColor = true;
            btnRecommend.Click += btnRecommend_Click_1;
            // 
            // dgvPets
            // 
            dgvPets.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvPets.Location = new Point(439, 95);
            dgvPets.Margin = new Padding(4);
            dgvPets.Name = "dgvPets";
            dgvPets.RowHeadersWidth = 51;
            dgvPets.Size = new Size(408, 259);
            dgvPets.TabIndex = 14;
            // 
            // cmbSize
            // 
            cmbSize.FormattingEnabled = true;
            cmbSize.Location = new Point(102, 276);
            cmbSize.Margin = new Padding(4);
            cmbSize.Name = "cmbSize";
            cmbSize.Size = new Size(188, 33);
            cmbSize.TabIndex = 13;
            // 
            // numAge
            // 
            numAge.Location = new Point(102, 210);
            numAge.Margin = new Padding(4);
            numAge.Name = "numAge";
            numAge.Size = new Size(188, 31);
            numAge.TabIndex = 12;
            // 
            // RecommendDogForm
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(866, 541);
            Controls.Add(cmbBreed);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(btnBack);
            Controls.Add(label1);
            Controls.Add(pbPets);
            Controls.Add(btnRecommend);
            Controls.Add(dgvPets);
            Controls.Add(cmbSize);
            Controls.Add(numAge);
            Name = "RecommendDogForm";
            Text = "RecommendDogForm";
            ((System.ComponentModel.ISupportInitialize)pbPets).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvPets).EndInit();
            ((System.ComponentModel.ISupportInitialize)numAge).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox cmbBreed;
        private Label label4;
        private Label label3;
        private Label label2;
        private Button btnBack;
        private Label label1;
        private PictureBox pbPets;
        private Button btnRecommend;
        private DataGridView dgvPets;
        private ComboBox cmbSize;
        private NumericUpDown numAge;
    }
}