﻿using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Data.OleDb;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace PetApplicationProject
{
    public partial class RegistrationForm : Form
    {
        string myDataBase = @"Provider=Microsoft.ACE.OLEDB.12.0; Data Source = PetApplicationDB.accdb";

        public RegistrationForm()
        {
            InitializeComponent();
        }

        private void ClearMethod()
        {
            txtFirstName.Text = "";
            txtLastName.Text = "";
            txtUsername.Text = "";
            txtEmail.Text = "";
            txtPassword.Text = "";
            txtPhone.Text = "";
            txtAddress.Text = "";

            rbCustomer.Checked = false;
            rbEmployee.Checked = false;
        }

        private bool ValidateInput(string username, string password, string email)
        {
            if (password.Length < 8 || !password.Any(char.IsDigit) || !password.Any(char.IsUpper))
            {
                MessageBox.Show("Your password must be at least 8 characters long and include at least one uppercase letter and one number.");
                return false;
            }

            if (!Regex.IsMatch(email, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
            {
                MessageBox.Show("Invalid email format.");
                return false;
            }

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password) || string.IsNullOrWhiteSpace(email))
            {
                MessageBox.Show("All fields are required.");
                return false;
            }

            return true;
        }

        private int GetRoleId()
        {
            if (rbCustomer.Checked)
            {
                return 1;
            }
            else if (rbEmployee.Checked)
            {
                return 2;
            }

            throw new Exception("Please select a role.");
        }

        private Users GetUserFromForm()
        {
            return new Users
            {
                Username = txtUsername.Text.Trim(),
                Email = txtEmail.Text.Trim(),
                Password = txtPassword.Text.Trim(),
                FirstName = txtFirstName.Text.Trim(),
                LastName = txtLastName.Text.Trim(),
                PhoneNum = string.IsNullOrWhiteSpace(txtPhone.Text) ? null : txtPhone.Text.Trim(),
                Address = string.IsNullOrWhiteSpace(txtAddress.Text) ? null : txtAddress.Text.Trim(),
                RoleID = GetRoleId()
            };
        }

        private void SaveUser(Users user)
        {
            if (user == null)
            {
                MessageBox.Show("User data is not valid.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                using (OleDbConnection conn = new OleDbConnection(myDataBase))
                {
                    conn.Open();
                    string query = "INSERT INTO Users ([Username], [Email], [Password], [FirstName], [LastName], [PhoneNum], [Address], [RoleID]) " +
                                   "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

                    using (OleDbCommand command = new OleDbCommand(query, conn))
                    {
                        command.Parameters.AddWithValue("@Username", user.Username);
                        command.Parameters.AddWithValue("@Email", user.Email);
                        command.Parameters.AddWithValue("@Password", user.Password);
                        command.Parameters.AddWithValue("@FirstName", user.FirstName);
                        command.Parameters.AddWithValue("@LastName", user.LastName);
                        command.Parameters.AddWithValue("@PhoneNum", string.IsNullOrWhiteSpace(user.PhoneNum) ? DBNull.Value : user.PhoneNum);
                        command.Parameters.AddWithValue("@Address", string.IsNullOrWhiteSpace(user.Address) ? DBNull.Value : user.Address);
                        command.Parameters.AddWithValue("@RoleID", user.RoleID);

                        command.ExecuteNonQuery();
                        MessageBox.Show("User registered successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while saving the user: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            if (ValidateInput(txtUsername.Text, txtPassword.Text, txtEmail.Text))
            {
                Users user = GetUserFromForm();
                SaveUser(user);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearMethod();
        }
    }
}