﻿using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PetApplicationProject
{
    public partial class LoginForm : Form
    {
        string myDataBase = "Provider=Microsoft.ACE.OLEDB.12.0; Data Source = PetApplicationDB.accdb";
        public LoginForm()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void lblRegister_Click(object sender, EventArgs e)
        {
            RegistrationForm register = new RegistrationForm();
            register.ShowDialog();
        }

        private (bool isValid, string fullName, int roleId, int userId) ValidateLogin(string username, string password)
        {
            string query = "SELECT FirstName, LastName, RoleID, UserID FROM Users WHERE Username = ? AND Password = ?";
            try
            {
                using (OleDbConnection conn = new OleDbConnection(myDataBase))
                {
                    conn.Open();
                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("?", username);
                        cmd.Parameters.AddWithValue("?", password);

                        using (OleDbDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                string firstName = reader["FirstName"].ToString();
                                string lastName = reader["LastName"].ToString();
                                string fullName = $"{firstName} {lastName}";
                                int roleId = Convert.ToInt32(reader["RoleID"]);
                                int userId = Convert.ToInt32(reader["UserID"]);

                              
                                return (true, fullName, roleId, userId);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred during login: {ex.Message}");
            }
            return (false, null, 0, 0);
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUserName.Text.Trim();
            string password = txtPassword.Text.Trim();

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Please enter both username and password.", "Login Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var (isValid, fullName, roleId, userId) = ValidateLogin(username, password);
            if (isValid)
            {
                DashboardForm db = new DashboardForm(fullName, roleId, userId);
                this.Hide();
                db.Show();
            }
            else
            {
                MessageBox.Show("Invalid username or password.", "Login Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void chkPassword_CheckedChanged(object sender, EventArgs e)
        {
            if(chkPassword.Checked)
            {
                txtPassword.PasswordChar = '\0';
            }
            else
            {
                txtPassword.PasswordChar = '*';
            }
        }
    }
}
