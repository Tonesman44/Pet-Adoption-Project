﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace PetApplicationProject
{
    public partial class DogManagementForm : Form
    {
        private string userName;
        private int roleId;
        private int loggedInUserId;

        string myDatabase = "Provider=Microsoft.ACE.OLEDB.12.0; Data Source = PetApplicationDB.accdb";
        public DogManagementForm(string userName, int roleID, int loggedInUserId)
        {
            InitializeComponent();
            LoadData();
            SizeComboBox();
            this.loggedInUserId = loggedInUserId;
            this.userName = userName;
            this.roleId = roleID;
        }

        private void SizeComboBox()
        {
            cmbSize.Items.Add("Small");
            cmbSize.Items.Add("Medium");
            cmbSize.Items.Add("Large");
            cmbSize.SelectedIndex = 0;
        }

        private void LoadData()
        {
            string query = "Select * From Dogs";

            try
            {
                using (OleDbConnection conn = new OleDbConnection(myDatabase))
                {
                    conn.Open();

                    OleDbDataAdapter adapter = new OleDbDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    dgvPets.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error has occurred {ex.Message}");
            }
        }

        private string Gender()
        {
            if (chkMale.Checked)
            {
                return "Male";
            }
            if (chkFemale.Checked)
            {
                return "Female";
            }
            return null;
        }
        private void ModifyPets(int dogID)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtName.Text) ||
                    string.IsNullOrWhiteSpace(txtBreed.Text) ||
                    string.IsNullOrWhiteSpace(txtAge.Text) ||
                    string.IsNullOrWhiteSpace(txtDescription.Text))
                {
                    MessageBox.Show("Please fill in all required fields.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                using (OleDbConnection conn = new OleDbConnection(myDatabase))
                {
                    conn.Open();

                    string query = "UPDATE Dogs SET [Name] = ?, [Breed] = ?, [Age] = ?, [Gender] = ?, [Size] = ?, [Description] = ? WHERE [DogID] = ?";
                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Name", txtName.Text.Trim());
                        cmd.Parameters.AddWithValue("@Breed", txtBreed.Text.Trim());
                        cmd.Parameters.AddWithValue("@Age", txtAge.Text.Trim());
                        cmd.Parameters.AddWithValue("@Gender", Gender());
                        cmd.Parameters.AddWithValue("@Size", cmbSize.SelectedItem?.ToString());
                        cmd.Parameters.AddWithValue("@Description", txtDescription.Text.Trim());
                        cmd.Parameters.AddWithValue("@DogID", dogID);

                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Dog updated successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadData();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error has occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void btnModify_Click(object sender, EventArgs e)
        {
            if (dgvPets.SelectedRows.Count > 0)
            {
                int dogID = Convert.ToInt32(dgvPets.SelectedRows[0].Cells["DogID"].Value);

                ModifyPets(dogID);
            }
            else
            {
                MessageBox.Show("Please select a book to modify.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void DeletePets(int dogID)
        {
            using (OleDbConnection conn = new OleDbConnection(myDatabase))
            {
                conn.Open();
                string query = "Delete From Dogs Where DogID = ?";

                using (OleDbCommand cmd = new OleDbCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@DogID", dogID);

                    cmd.ExecuteNonQuery();
                }
                MessageBox.Show("Data Deleted Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            LoadData();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvPets.SelectedRows.Count > 0)
            {
                int dogID = Convert.ToInt32(dgvPets.SelectedRows[0].Cells["DogID"].Value);

                DeletePets(dogID);
            }
            else
            {
                MessageBox.Show("Please select a book to delete", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void AddDogToDatabase()
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtName.Text) ||
                    string.IsNullOrWhiteSpace(txtBreed.Text) ||
                    string.IsNullOrWhiteSpace(txtAge.Text) ||
                    string.IsNullOrWhiteSpace(txtDescription.Text) ||
                    cmbSize.SelectedItem == null ||
                    !(chkMale.Checked || chkFemale.Checked))
                {
                    MessageBox.Show("Please fill in all required fields and select a gender.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string query = @"
                INSERT INTO Dogs ([Name], [Breed], [Age], [Gender], [Size], [Description], [ShelterEmployeeID]) 
                VALUES (?, ?, ?, ?, ?, ?, ?)";

                using (OleDbConnection conn = new OleDbConnection(myDatabase))
                {
                    conn.Open();

                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    {
                        string gender = chkMale.Checked ? "Male" : "Female";
                        string size = cmbSize.SelectedItem.ToString();
                        int age;

                        if (!int.TryParse(txtAge.Text, out age) || age < 0)
                        {
                            MessageBox.Show("Please enter a valid age.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }

                        int shelterEmployeeId = loggedInUserId;

                        cmd.Parameters.AddWithValue("?", txtName.Text);
                        cmd.Parameters.AddWithValue("?", txtBreed.Text);
                        cmd.Parameters.AddWithValue("?", age);
                        cmd.Parameters.AddWithValue("?", gender);
                        cmd.Parameters.AddWithValue("?", size);
                        cmd.Parameters.AddWithValue("?", txtDescription.Text);
                     
                        cmd.Parameters.AddWithValue("?", shelterEmployeeId);

                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Dog added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error occurred during database operation: {ex.Message}", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



        private void btnAdd_Click(object sender, EventArgs e)
        {
            AddDogToDatabase();
            LoadData();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
            DashboardForm df = new DashboardForm(userName, roleId, loggedInUserId);
            df.ShowDialog();
        }
    }
}
