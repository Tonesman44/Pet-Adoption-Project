﻿namespace PetApplicationProject
{
    partial class DashboardForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgvDogs = new DataGridView();
            btnSettings = new Button();
            label1 = new Label();
            label2 = new Label();
            lblUser = new Label();
            btnApply = new Button();
            btnAdd = new Button();
            btnSearch = new Button();
            btnProfile = new Button();
            groupBox1 = new GroupBox();
            btnData = new Button();
            btnAdminPanel = new Button();
            btnRecommendation = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvDogs).BeginInit();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // dgvDogs
            // 
            dgvDogs.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvDogs.Location = new Point(202, 101);
            dgvDogs.Margin = new Padding(2);
            dgvDogs.Name = "dgvDogs";
            dgvDogs.RowHeadersWidth = 62;
            dgvDogs.Size = new Size(710, 661);
            dgvDogs.TabIndex = 0;
            // 
            // btnSettings
            // 
            btnSettings.Location = new Point(10, 392);
            btnSettings.Margin = new Padding(2);
            btnSettings.Name = "btnSettings";
            btnSettings.Size = new Size(174, 59);
            btnSettings.TabIndex = 2;
            btnSettings.Text = "Settings";
            btnSettings.UseVisualStyleBackColor = true;
            btnSettings.Click += btnSettings_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F);
            label1.Location = new Point(202, 64);
            label1.Margin = new Padding(2, 0, 2, 0);
            label1.Name = "label1";
            label1.Size = new Size(177, 32);
            label1.TabIndex = 4;
            label1.Text = "Available Dogs:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 20F);
            label2.Location = new Point(394, 19);
            label2.Margin = new Padding(2, 0, 2, 0);
            label2.Name = "label2";
            label2.Size = new Size(506, 54);
            label2.TabIndex = 5;
            label2.Text = "Welcome to the Dashboard";
            // 
            // lblUser
            // 
            lblUser.AutoSize = true;
            lblUser.Font = new Font("Segoe UI", 12F);
            lblUser.Location = new Point(12, 9);
            lblUser.Margin = new Padding(2, 0, 2, 0);
            lblUser.Name = "lblUser";
            lblUser.Size = new Size(174, 32);
            lblUser.TabIndex = 6;
            lblUser.Text = "Welcome User!";
            // 
            // btnApply
            // 
            btnApply.Location = new Point(10, 136);
            btnApply.Margin = new Padding(2);
            btnApply.Name = "btnApply";
            btnApply.Size = new Size(174, 58);
            btnApply.TabIndex = 7;
            btnApply.Text = "Apply";
            btnApply.UseVisualStyleBackColor = true;
            btnApply.Click += btnApply_Click;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(10, 560);
            btnAdd.Margin = new Padding(2);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(174, 55);
            btnAdd.TabIndex = 9;
            btnAdd.Text = "Add Dog";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnSearch
            // 
            btnSearch.Location = new Point(10, 49);
            btnSearch.Margin = new Padding(2);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(174, 61);
            btnSearch.TabIndex = 10;
            btnSearch.Text = "Search";
            btnSearch.UseVisualStyleBackColor = true;
            btnSearch.Click += btnSearch_Click;
            // 
            // btnProfile
            // 
            btnProfile.Location = new Point(10, 301);
            btnProfile.Margin = new Padding(2);
            btnProfile.Name = "btnProfile";
            btnProfile.Size = new Size(174, 62);
            btnProfile.TabIndex = 11;
            btnProfile.Text = "Selected Dog Profile";
            btnProfile.UseVisualStyleBackColor = true;
            btnProfile.Click += btnProfile_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(btnData);
            groupBox1.Controls.Add(btnAdminPanel);
            groupBox1.Controls.Add(btnRecommendation);
            groupBox1.Controls.Add(btnSearch);
            groupBox1.Controls.Add(btnAdd);
            groupBox1.Controls.Add(btnProfile);
            groupBox1.Controls.Add(btnApply);
            groupBox1.Controls.Add(btnSettings);
            groupBox1.Location = new Point(2, 64);
            groupBox1.Margin = new Padding(2);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(2);
            groupBox1.Size = new Size(195, 698);
            groupBox1.TabIndex = 13;
            groupBox1.TabStop = false;
            groupBox1.Text = "Dropdown:";
            // 
            // btnData
            // 
            btnData.Location = new Point(10, 473);
            btnData.Margin = new Padding(2);
            btnData.Name = "btnData";
            btnData.Size = new Size(179, 59);
            btnData.TabIndex = 17;
            btnData.Text = "Data";
            btnData.UseVisualStyleBackColor = true;
            btnData.Click += btnData_Click;
            // 
            // btnAdminPanel
            // 
            btnAdminPanel.Location = new Point(10, 643);
            btnAdminPanel.Margin = new Padding(2);
            btnAdminPanel.Name = "btnAdminPanel";
            btnAdminPanel.Size = new Size(174, 55);
            btnAdminPanel.TabIndex = 13;
            btnAdminPanel.Text = "Admin Panel";
            btnAdminPanel.UseVisualStyleBackColor = true;
            btnAdminPanel.Click += btnAdminPanel_Click;
            // 
            // btnRecommendation
            // 
            btnRecommendation.Location = new Point(10, 215);
            btnRecommendation.Margin = new Padding(2);
            btnRecommendation.Name = "btnRecommendation";
            btnRecommendation.Size = new Size(179, 59);
            btnRecommendation.TabIndex = 16;
            btnRecommendation.Text = "Recommendation";
            btnRecommendation.UseVisualStyleBackColor = true;
            btnRecommendation.Click += btnRecommendation_Click;
            // 
            // DashboardForm
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(952, 838);
            Controls.Add(groupBox1);
            Controls.Add(lblUser);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(dgvDogs);
            Margin = new Padding(2);
            Name = "DashboardForm";
            Text = "DashboardForm";
            Load += DashboardForm_Load;
            ((System.ComponentModel.ISupportInitialize)dgvDogs).EndInit();
            groupBox1.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgvDogs;
        private Button btnSettings;
        private Label label1;
        private Label label2;
        private Label lblUser;
        private Button btnApply;
        private Button btnAdd;
        private Button btnSearch;
        private Button btnProfile;
        private GroupBox groupBox1;
        private Button btnAdminPanel;
        private Button btnData;
        private Button btnRecommendation;
    }
}