﻿namespace PetApplicationProject
{
    partial class DogBrowseForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgvDogs = new DataGridView();
            btnClearFilters = new Button();
            label3 = new Label();
            groupBox1 = new GroupBox();
            btnSearchBreed = new Button();
            txtBreed = new TextBox();
            label4 = new Label();
            groupBox2 = new GroupBox();
            label6 = new Label();
            txtAgeFrom = new TextBox();
            btnSearchAge = new Button();
            txtAgeTo = new TextBox();
            label2 = new Label();
            btnLoad = new Button();
            groupBox3 = new GroupBox();
            btnSearchSize = new Button();
            txtSize = new TextBox();
            label5 = new Label();
            btnReturn = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvDogs).BeginInit();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            SuspendLayout();
            // 
            // dgvDogs
            // 
            dgvDogs.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvDogs.Location = new Point(53, 113);
            dgvDogs.Margin = new Padding(4, 5, 4, 5);
            dgvDogs.Name = "dgvDogs";
            dgvDogs.RowHeadersWidth = 62;
            dgvDogs.Size = new Size(343, 250);
            dgvDogs.TabIndex = 0;
            // 
            // btnClearFilters
            // 
            btnClearFilters.Location = new Point(243, 387);
            btnClearFilters.Margin = new Padding(4, 5, 4, 5);
            btnClearFilters.Name = "btnClearFilters";
            btnClearFilters.Size = new Size(153, 59);
            btnClearFilters.TabIndex = 4;
            btnClearFilters.Text = "Clear Filters";
            btnClearFilters.UseVisualStyleBackColor = true;
            btnClearFilters.Click += btnClearFilters_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(8, 38);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(61, 25);
            label3.TabIndex = 8;
            label3.Text = "Breed:";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(btnSearchBreed);
            groupBox1.Controls.Add(txtBreed);
            groupBox1.Controls.Add(label3);
            groupBox1.Location = new Point(423, 97);
            groupBox1.Margin = new Padding(4, 5, 4, 5);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(4, 5, 4, 5);
            groupBox1.Size = new Size(370, 147);
            groupBox1.TabIndex = 9;
            groupBox1.TabStop = false;
            groupBox1.Text = "Search by Breed:";
            // 
            // btnSearchBreed
            // 
            btnSearchBreed.Location = new Point(185, 53);
            btnSearchBreed.Margin = new Padding(4, 5, 4, 5);
            btnSearchBreed.Name = "btnSearchBreed";
            btnSearchBreed.Size = new Size(140, 53);
            btnSearchBreed.TabIndex = 10;
            btnSearchBreed.Text = "Search Breed";
            btnSearchBreed.UseVisualStyleBackColor = true;
            btnSearchBreed.Click += btnSearchBreed_Click;
            // 
            // txtBreed
            // 
            txtBreed.Location = new Point(8, 75);
            txtBreed.Name = "txtBreed";
            txtBreed.Size = new Size(150, 31);
            txtBreed.TabIndex = 9;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 24F);
            label4.Location = new Point(13, 9);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(804, 65);
            label4.TabIndex = 10;
            label4.Text = "Browse Dogs by Specific Information";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(label6);
            groupBox2.Controls.Add(txtAgeFrom);
            groupBox2.Controls.Add(btnSearchAge);
            groupBox2.Controls.Add(txtAgeTo);
            groupBox2.Controls.Add(label2);
            groupBox2.Location = new Point(423, 254);
            groupBox2.Margin = new Padding(4, 5, 4, 5);
            groupBox2.Name = "groupBox2";
            groupBox2.Padding = new Padding(4, 5, 4, 5);
            groupBox2.Size = new Size(370, 215);
            groupBox2.TabIndex = 11;
            groupBox2.TabStop = false;
            groupBox2.Text = "Search by Age:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(9, 134);
            label6.Margin = new Padding(4, 0, 4, 0);
            label6.Name = "label6";
            label6.Size = new Size(95, 25);
            label6.TabIndex = 13;
            label6.Text = "Age From:";
            // 
            // txtAgeFrom
            // 
            txtAgeFrom.Location = new Point(8, 161);
            txtAgeFrom.Name = "txtAgeFrom";
            txtAgeFrom.Size = new Size(150, 31);
            txtAgeFrom.TabIndex = 12;
            // 
            // btnSearchAge
            // 
            btnSearchAge.Location = new Point(185, 92);
            btnSearchAge.Margin = new Padding(4, 5, 4, 5);
            btnSearchAge.Name = "btnSearchAge";
            btnSearchAge.Size = new Size(140, 53);
            btnSearchAge.TabIndex = 11;
            btnSearchAge.Text = "Search Ages";
            btnSearchAge.UseVisualStyleBackColor = true;
            btnSearchAge.Click += btnSearchAge_Click_1;
            // 
            // txtAgeTo
            // 
            txtAgeTo.Location = new Point(9, 75);
            txtAgeTo.Name = "txtAgeTo";
            txtAgeTo.Size = new Size(150, 31);
            txtAgeTo.TabIndex = 9;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(9, 40);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(71, 25);
            label2.TabIndex = 8;
            label2.Text = "Age To:";
            // 
            // btnLoad
            // 
            btnLoad.Location = new Point(53, 387);
            btnLoad.Name = "btnLoad";
            btnLoad.Size = new Size(153, 59);
            btnLoad.TabIndex = 12;
            btnLoad.Text = "Reset Data";
            btnLoad.UseVisualStyleBackColor = true;
            btnLoad.Click += btnLoad_Click;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(btnSearchSize);
            groupBox3.Controls.Add(txtSize);
            groupBox3.Controls.Add(label5);
            groupBox3.Location = new Point(423, 479);
            groupBox3.Margin = new Padding(4, 5, 4, 5);
            groupBox3.Name = "groupBox3";
            groupBox3.Padding = new Padding(4, 5, 4, 5);
            groupBox3.Size = new Size(370, 147);
            groupBox3.TabIndex = 13;
            groupBox3.TabStop = false;
            groupBox3.Text = "Search by Size:";
            // 
            // btnSearchSize
            // 
            btnSearchSize.Location = new Point(185, 53);
            btnSearchSize.Margin = new Padding(4, 5, 4, 5);
            btnSearchSize.Name = "btnSearchSize";
            btnSearchSize.Size = new Size(140, 53);
            btnSearchSize.TabIndex = 11;
            btnSearchSize.Text = "Search Size:";
            btnSearchSize.UseVisualStyleBackColor = true;
            btnSearchSize.Click += btnSearchSize_Click;
            // 
            // txtSize
            // 
            txtSize.Location = new Point(8, 75);
            txtSize.Name = "txtSize";
            txtSize.Size = new Size(150, 31);
            txtSize.TabIndex = 9;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(9, 40);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(47, 25);
            label5.TabIndex = 8;
            label5.Text = "Size:";
            // 
            // btnReturn
            // 
            btnReturn.Location = new Point(53, 479);
            btnReturn.Name = "btnReturn";
            btnReturn.Size = new Size(343, 65);
            btnReturn.TabIndex = 14;
            btnReturn.Text = "Return to Dashboard";
            btnReturn.UseVisualStyleBackColor = true;
            btnReturn.Click += btnReturn_Click;
            // 
            // DogBrowseForm
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(820, 710);
            Controls.Add(btnReturn);
            Controls.Add(groupBox3);
            Controls.Add(btnLoad);
            Controls.Add(groupBox2);
            Controls.Add(label4);
            Controls.Add(groupBox1);
            Controls.Add(btnClearFilters);
            Controls.Add(dgvDogs);
            Margin = new Padding(4, 5, 4, 5);
            Name = "DogBrowseForm";
            Text = "DogBrowseForm";
            ((System.ComponentModel.ISupportInitialize)dgvDogs).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgvDogs;
        private Button btnClearFilters;
        private Label label3;
        private GroupBox groupBox1;
        private Label label4;
        private GroupBox groupBox2;
        private Label label2;
        private TextBox txtBreed;
        private TextBox txtAgeTo;
        private Button btnLoad;
        private GroupBox groupBox3;
        private TextBox txtSize;
        private Label label5;
        private Button btnSearchBreed;
        private Label label6;
        private TextBox txtAgeFrom;
        private Button btnSearchAge;
        private Button btnSearchSize;
        private Button btnReturn;
    }
}