﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace PetApplicationProject
{
    public partial class AnalyticsForm : Form
    {
        string myDatabase = "Provider=Microsoft.ACE.OLEDB.12.0; Data Source = PetApplicationDB.accdb";
        public AnalyticsForm(string userName, int roleId, int loggedInUserId)
        {
            InitializeComponent();
            LoadBreedChart();
            LoadData();
            this.userName = userName;
            this.roleId = roleId;
            this.loggedInUserId = loggedInUserId;
        }

        private void LoadData()
        {
            string query = "Select Name, Breed From Dogs";
            try
            {
                using (OleDbConnection conn = new OleDbConnection(myDatabase))
                {
                    conn.Open();
                    OleDbDataAdapter adapter = new OleDbDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    dgvPets.DataSource = dt;
                    dgvPets.ReadOnly = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error has occurred {ex.Message}");
            }
        }

        private string userName;
        private int roleId;
        private int loggedInUserId;

        private DataTable GetBreeds()
        {
            DataTable dt = new DataTable();
            try
            {
                using (OleDbConnection conn = new OleDbConnection(myDatabase))
                {
                    conn.Open();
                    string query = "SELECT Breed, COUNT(*) AS BreedCount FROM Dogs GROUP BY Breed";
                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    using (OleDbDataAdapter adapter = new OleDbDataAdapter(cmd))
                    {
                        adapter.Fill(dt);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error fetching breed data: {ex.Message}", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return dt;
        }


        private void LoadBreedChart()
        {
            DataTable breedCounts = GetBreeds();

            if (breedCounts.Rows.Count == 0)
            {
                MessageBox.Show("No data available to display in the chart.", "No Data", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            chartPets.Series.Clear();

            Series series = new Series
            {
                Name = "Breeds",
                ChartType = SeriesChartType.Pie,
                IsValueShownAsLabel = true
            };

            foreach (DataRow row in breedCounts.Rows)
            {
                string breed = row["Breed"].ToString();
                int count = Convert.ToInt32(row["BreedCount"]);
                series.Points.AddXY(breed, count);
            }

            chartPets.Series.Add(series);
            chartPets.Titles.Clear();
            chartPets.Titles.Add("Breed Distribution");
        }

        private void btnBack_Click_1(object sender, EventArgs e)
        {
            this.Close();
            DashboardForm df = new DashboardForm(userName, roleId, loggedInUserId);
            df.ShowDialog();
        }
    }
}
