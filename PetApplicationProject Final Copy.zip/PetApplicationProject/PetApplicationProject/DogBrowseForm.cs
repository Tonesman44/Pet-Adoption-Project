﻿using System;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;

namespace PetApplicationProject
{
    public partial class DogBrowseForm : Form
    {
        private string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0; Data Source=PetApplicationDB.accdb";
        private DataTable dogsTable;
        private string userName;
        private int roleID;
        private int userID;

        public DogBrowseForm(string userName, int roleID, int userID)
        {
            InitializeComponent();
            LoadDogs();
            this.userName = userName;
            this.roleID = roleID;
            this.userID = userID;
        }

        private void DogBrowseForm_Load(object sender, EventArgs e)
        {
            LoadDogs();
        }

        private void LoadDogs()
        {
            string query = "SELECT * FROM Dogs";

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    OleDbDataAdapter adapter = new OleDbDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    dgvDogs.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error occurred while loading data: {ex.Message}");
                }
            }
        }



        private void btnSearch_Click(object sender, EventArgs e)
        {
            string query = "SELECT DogID, Name, Age, Breed FROM Dogs WHERE Status <> 'Adopted'";

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    OleDbDataAdapter adapter = new OleDbDataAdapter(query, conn);
                    dogsTable = new DataTable();
                    adapter.Fill(dogsTable);
                    dgvDogs.DataSource = dogsTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error filtering dogs: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            LoadDogs();
        }

        private void btnClearFilters_Click(object sender, EventArgs e)
        {
            txtAgeFrom.Clear();
            txtAgeTo.Clear();
            txtBreed.Clear();
            txtSize.Clear();
        }

        private void btnSearchBreed_Click(object sender, EventArgs e)
        {
            string breed = txtBreed.Text.Trim();
            if (string.IsNullOrEmpty(breed))
            {
                MessageBox.Show("Please enter a breed to search.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string query = "SELECT DogID, Name, Age, Breed FROM Dogs WHERE Breed LIKE @Breed";

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Breed", "%" + breed + "%");
                        OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
                        dogsTable = new DataTable();
                        adapter.Fill(dogsTable);
                        dgvDogs.DataSource = dogsTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error filtering by breed: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnSearchAge_Click_1(object sender, EventArgs e)
        {
            if (!int.TryParse(txtAgeFrom.Text.Trim(), out int ageFrom) || !int.TryParse(txtAgeTo.Text.Trim(), out int ageTo))
            {
                MessageBox.Show("Please enter valid age range values.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string query = "SELECT DogID, Name, Age, Breed FROM Dogs WHERE Age BETWEEN @AgeFrom AND @AgeTo";

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@AgeFrom", ageFrom);
                        cmd.Parameters.AddWithValue("@AgeTo", ageTo);
                        OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
                        dogsTable = new DataTable();
                        adapter.Fill(dogsTable);
                        dgvDogs.DataSource = dogsTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error filtering by age range: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnSearchSize_Click(object sender, EventArgs e)
        {
            string size = txtSize.Text.Trim();
            if (string.IsNullOrEmpty(size))
            {
                MessageBox.Show("Please enter a size to search.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string query = "SELECT DogID, Name, Age, Breed FROM Dogs WHERE Size = @Size";

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Size", size);
                        OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
                        dogsTable = new DataTable();
                        adapter.Fill(dogsTable);
                        dgvDogs.DataSource = dogsTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error filtering by size: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            this.Close();
            DashboardForm db = new DashboardForm(userName, roleID, userID);
            db.ShowDialog();
        }
    }
}
