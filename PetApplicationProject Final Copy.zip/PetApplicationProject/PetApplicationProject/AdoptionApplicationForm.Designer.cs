﻿namespace PetApplicationProject
{
    partial class AdoptionApplicationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label5 = new Label();
            cmbDogSelection = new ComboBox();
            groupBox3 = new GroupBox();
            label1 = new Label();
            cmbStatus = new ComboBox();
            btnCancel = new Button();
            btnSubmit = new Button();
            lblUserID = new Label();
            label2 = new Label();
            groupPets = new GroupBox();
            rbtnQ1No = new RadioButton();
            rbtnQ1Yes = new RadioButton();
            label3 = new Label();
            groupStable = new GroupBox();
            rbtnQ2No = new RadioButton();
            rbtnQ2Yes = new RadioButton();
            label4 = new Label();
            groupChildren = new GroupBox();
            rbtnQ3No = new RadioButton();
            rbtnQ3Yes = new RadioButton();
            label6 = new Label();
            groupAmount = new GroupBox();
            groupBox6 = new GroupBox();
            textBox1 = new TextBox();
            label9 = new Label();
            nudAmountPets = new NumericUpDown();
            label7 = new Label();
            groupAfterCare = new GroupBox();
            txtAfterCare = new TextBox();
            label10 = new Label();
            groupBox3.SuspendLayout();
            groupPets.SuspendLayout();
            groupStable.SuspendLayout();
            groupChildren.SuspendLayout();
            groupAmount.SuspendLayout();
            groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)nudAmountPets).BeginInit();
            groupAfterCare.SuspendLayout();
            SuspendLayout();
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(186, 43);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(135, 25);
            label5.TabIndex = 2;
            label5.Text = "Available Dogs:";
            // 
            // cmbDogSelection
            // 
            cmbDogSelection.FormattingEnabled = true;
            cmbDogSelection.Location = new Point(186, 73);
            cmbDogSelection.Margin = new Padding(4, 5, 4, 5);
            cmbDogSelection.Name = "cmbDogSelection";
            cmbDogSelection.Size = new Size(171, 33);
            cmbDogSelection.TabIndex = 0;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(label1);
            groupBox3.Controls.Add(cmbStatus);
            groupBox3.Controls.Add(btnCancel);
            groupBox3.Controls.Add(cmbDogSelection);
            groupBox3.Controls.Add(label5);
            groupBox3.Controls.Add(btnSubmit);
            groupBox3.Location = new Point(124, 492);
            groupBox3.Margin = new Padding(4, 5, 4, 5);
            groupBox3.Name = "groupBox3";
            groupBox3.Padding = new Padding(4, 5, 4, 5);
            groupBox3.Size = new Size(899, 264);
            groupBox3.TabIndex = 4;
            groupBox3.TabStop = false;
            groupBox3.Text = "Application Details:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(490, 43);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(60, 25);
            label1.TabIndex = 12;
            label1.Text = "Status";
            // 
            // cmbStatus
            // 
            cmbStatus.FormattingEnabled = true;
            cmbStatus.Items.AddRange(new object[] { "Pending", "Adopted" });
            cmbStatus.Location = new Point(490, 73);
            cmbStatus.Margin = new Padding(4, 5, 4, 5);
            cmbStatus.Name = "cmbStatus";
            cmbStatus.Size = new Size(171, 33);
            cmbStatus.TabIndex = 11;
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(490, 154);
            btnCancel.Margin = new Padding(4, 5, 4, 5);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(189, 67);
            btnCancel.TabIndex = 6;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click_1;
            // 
            // btnSubmit
            // 
            btnSubmit.Location = new Point(186, 154);
            btnSubmit.Margin = new Padding(4, 5, 4, 5);
            btnSubmit.Name = "btnSubmit";
            btnSubmit.Size = new Size(189, 67);
            btnSubmit.TabIndex = 5;
            btnSubmit.Text = "Submit";
            btnSubmit.UseVisualStyleBackColor = true;
            btnSubmit.Click += btnSubmit_Click;
            // 
            // lblUserID
            // 
            lblUserID.AutoSize = true;
            lblUserID.Location = new Point(17, 15);
            lblUserID.Margin = new Padding(4, 0, 4, 0);
            lblUserID.Name = "lblUserID";
            lblUserID.Size = new Size(65, 25);
            lblUserID.TabIndex = 8;
            lblUserID.Text = "UserID";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 24F);
            label2.Location = new Point(236, 15);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(601, 65);
            label2.TabIndex = 9;
            label2.Text = "Adoption Application Form";
            // 
            // groupPets
            // 
            groupPets.Controls.Add(rbtnQ1No);
            groupPets.Controls.Add(rbtnQ1Yes);
            groupPets.Controls.Add(label3);
            groupPets.Location = new Point(50, 114);
            groupPets.Name = "groupPets";
            groupPets.Size = new Size(300, 150);
            groupPets.TabIndex = 10;
            groupPets.TabStop = false;
            groupPets.Text = "Question 1:";
            // 
            // rbtnQ1No
            // 
            rbtnQ1No.AutoSize = true;
            rbtnQ1No.Location = new Point(43, 100);
            rbtnQ1No.Name = "rbtnQ1No";
            rbtnQ1No.Size = new Size(61, 29);
            rbtnQ1No.TabIndex = 2;
            rbtnQ1No.TabStop = true;
            rbtnQ1No.Text = "No";
            rbtnQ1No.UseVisualStyleBackColor = true;
            // 
            // rbtnQ1Yes
            // 
            rbtnQ1Yes.AutoSize = true;
            rbtnQ1Yes.Location = new Point(43, 65);
            rbtnQ1Yes.Name = "rbtnQ1Yes";
            rbtnQ1Yes.Size = new Size(62, 29);
            rbtnQ1Yes.TabIndex = 1;
            rbtnQ1Yes.TabStop = true;
            rbtnQ1Yes.Text = "Yes";
            rbtnQ1Yes.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(21, 37);
            label3.Name = "label3";
            label3.Size = new Size(226, 25);
            label3.TabIndex = 0;
            label3.Text = "Have you had pets before?";
            // 
            // groupStable
            // 
            groupStable.Controls.Add(rbtnQ2No);
            groupStable.Controls.Add(rbtnQ2Yes);
            groupStable.Controls.Add(label4);
            groupStable.Location = new Point(416, 114);
            groupStable.Name = "groupStable";
            groupStable.Size = new Size(334, 150);
            groupStable.TabIndex = 11;
            groupStable.TabStop = false;
            groupStable.Text = "Question 2:";
            // 
            // rbtnQ2No
            // 
            rbtnQ2No.AutoSize = true;
            rbtnQ2No.Location = new Point(43, 100);
            rbtnQ2No.Name = "rbtnQ2No";
            rbtnQ2No.Size = new Size(61, 29);
            rbtnQ2No.TabIndex = 2;
            rbtnQ2No.TabStop = true;
            rbtnQ2No.Text = "No";
            rbtnQ2No.UseVisualStyleBackColor = true;
            // 
            // rbtnQ2Yes
            // 
            rbtnQ2Yes.AutoSize = true;
            rbtnQ2Yes.Location = new Point(43, 65);
            rbtnQ2Yes.Name = "rbtnQ2Yes";
            rbtnQ2Yes.Size = new Size(62, 29);
            rbtnQ2Yes.TabIndex = 1;
            rbtnQ2Yes.TabStop = true;
            rbtnQ2Yes.Text = "Yes";
            rbtnQ2Yes.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(21, 37);
            label4.Name = "label4";
            label4.Size = new Size(307, 25);
            label4.TabIndex = 0;
            label4.Text = "Do you have a stable living situation?";
            // 
            // groupChildren
            // 
            groupChildren.Controls.Add(rbtnQ3No);
            groupChildren.Controls.Add(rbtnQ3Yes);
            groupChildren.Controls.Add(label6);
            groupChildren.Location = new Point(807, 122);
            groupChildren.Name = "groupChildren";
            groupChildren.Size = new Size(300, 150);
            groupChildren.TabIndex = 12;
            groupChildren.TabStop = false;
            groupChildren.Text = "Question 3:";
            // 
            // rbtnQ3No
            // 
            rbtnQ3No.AutoSize = true;
            rbtnQ3No.Location = new Point(43, 100);
            rbtnQ3No.Name = "rbtnQ3No";
            rbtnQ3No.Size = new Size(61, 29);
            rbtnQ3No.TabIndex = 2;
            rbtnQ3No.TabStop = true;
            rbtnQ3No.Text = "No";
            rbtnQ3No.UseVisualStyleBackColor = true;
            // 
            // rbtnQ3Yes
            // 
            rbtnQ3Yes.AutoSize = true;
            rbtnQ3Yes.Location = new Point(43, 65);
            rbtnQ3Yes.Name = "rbtnQ3Yes";
            rbtnQ3Yes.Size = new Size(62, 29);
            rbtnQ3Yes.TabIndex = 1;
            rbtnQ3Yes.TabStop = true;
            rbtnQ3Yes.Text = "Yes";
            rbtnQ3Yes.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(21, 37);
            label6.Name = "label6";
            label6.Size = new Size(221, 25);
            label6.TabIndex = 0;
            label6.Text = "Do you have any children?";
            // 
            // groupAmount
            // 
            groupAmount.Controls.Add(groupBox6);
            groupAmount.Controls.Add(nudAmountPets);
            groupAmount.Controls.Add(label7);
            groupAmount.Location = new Point(124, 305);
            groupAmount.Name = "groupAmount";
            groupAmount.Size = new Size(420, 150);
            groupAmount.TabIndex = 13;
            groupAmount.TabStop = false;
            groupAmount.Text = "Question 4:";
            // 
            // groupBox6
            // 
            groupBox6.Controls.Add(textBox1);
            groupBox6.Controls.Add(label9);
            groupBox6.Location = new Point(416, 37);
            groupBox6.Name = "groupBox6";
            groupBox6.Size = new Size(302, 150);
            groupBox6.TabIndex = 14;
            groupBox6.TabStop = false;
            groupBox6.Text = "Question 5:";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(32, 81);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(264, 31);
            textBox1.TabIndex = 1;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(21, 37);
            label9.Name = "label9";
            label9.Size = new Size(282, 25);
            label9.TabIndex = 0;
            label9.Text = "Explain how you will do after-care.";
            // 
            // nudAmountPets
            // 
            nudAmountPets.Location = new Point(21, 76);
            nudAmountPets.Name = "nudAmountPets";
            nudAmountPets.Size = new Size(389, 31);
            nudAmountPets.TabIndex = 1;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(21, 37);
            label7.Name = "label7";
            label7.Size = new Size(397, 25);
            label7.TabIndex = 0;
            label7.Text = "Do you currently have any pets, if so how many?";
            // 
            // groupAfterCare
            // 
            groupAfterCare.Controls.Add(txtAfterCare);
            groupAfterCare.Controls.Add(label10);
            groupAfterCare.Location = new Point(590, 305);
            groupAfterCare.Name = "groupAfterCare";
            groupAfterCare.Size = new Size(433, 150);
            groupAfterCare.TabIndex = 14;
            groupAfterCare.TabStop = false;
            groupAfterCare.Text = "Question 5:";
            // 
            // txtAfterCare
            // 
            txtAfterCare.Location = new Point(33, 81);
            txtAfterCare.Name = "txtAfterCare";
            txtAfterCare.Size = new Size(383, 31);
            txtAfterCare.TabIndex = 1;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(21, 37);
            label10.Name = "label10";
            label10.Size = new Size(282, 25);
            label10.TabIndex = 0;
            label10.Text = "Explain how you will do after-care.";
            // 
            // AdoptionApplicationForm
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(1150, 770);
            Controls.Add(groupAfterCare);
            Controls.Add(groupAmount);
            Controls.Add(groupChildren);
            Controls.Add(groupStable);
            Controls.Add(groupPets);
            Controls.Add(label2);
            Controls.Add(lblUserID);
            Controls.Add(groupBox3);
            Margin = new Padding(4, 5, 4, 5);
            Name = "AdoptionApplicationForm";
            Text = "AdoptionApplicationForm";
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            groupPets.ResumeLayout(false);
            groupPets.PerformLayout();
            groupStable.ResumeLayout(false);
            groupStable.PerformLayout();
            groupChildren.ResumeLayout(false);
            groupChildren.PerformLayout();
            groupAmount.ResumeLayout(false);
            groupAmount.PerformLayout();
            groupBox6.ResumeLayout(false);
            groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)nudAmountPets).EndInit();
            groupAfterCare.ResumeLayout(false);
            groupAfterCare.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label5;
        private ComboBox cmbDogSelection;
        private GroupBox groupBox3;
        private Button btnSubmit;
        private Button btnCancel;
        private Label lblUserID;
        private Label label1;
        private ComboBox cmbStatus;
        private Label label2;
        private GroupBox groupPets;
        private RadioButton rbtnQ1No;
        private RadioButton rbtnQ1Yes;
        private Label label3;
        private GroupBox groupStable;
        private RadioButton rbtnQ2No;
        private RadioButton rbtnQ2Yes;
        private Label label4;
        private GroupBox groupChildren;
        private RadioButton rbtnQ3No;
        private RadioButton rbtnQ3Yes;
        private Label label6;
        private GroupBox groupAmount;
        private NumericUpDown nudAmountPets;
        private Label label7;
        private GroupBox groupBox6;
        private TextBox textBox1;
        private Label label9;
        private GroupBox groupAfterCare;
        private TextBox txtAfterCare;
        private Label label10;
    }
}