﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace PetApplicationProject
{
    public partial class RecommendDogForm : Form
    {
        private readonly string myDatabase = "Provider=Microsoft.ACE.OLEDB.12.0; Data Source=PetApplicationDB.accdb";

        private readonly Dictionary<string, string> breeds = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            { "cockapoo", "https://www.dailypaws.com/thmb/XPsqZiY5B3hNQN8SofRuQZW6268=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/cockapoo-red-colored-greenery-223686877-2000-08327a0071b54ddf84c7960069d56d95.jpg" },
            { "boxer", "https://cdn.britannica.com/46/233846-050-8D30A43B/Boxer-dog.jpg" },
            { "golden retriever", "https://www.akc.org/wp-content/uploads/2020/07/Golden-Retriever-puppy-standing-outdoors.jpg" },
            { "poodle", "https://upload.wikimedia.org/wikipedia/commons/thumb/f/f8/Full_attention_%288067543690%29.jpg/1200px-Full_attention_%288067543690%29.jpg" },
            { "labrador", "https://images.wagwalkingweb.com/media/daily_wag/blog_articles/hero/1670938235.1927571/fun-facts-about-labrador-retrievers.jpg" },
            { "chihuahua", "https://cdn.britannica.com/44/233244-050-A65D4571/Chihuahua-dog.jpg" },
            { "beagle", "https://www.bil-jac.com/media/ambgc3os/beagle2-184102750.jpg?anchor=center&mode=crop&width=600&height=400&rnd=132167289621930000&format=webp&quality=80" },
            { "bulldog", "https://upload.wikimedia.org/wikipedia/commons/thumb/b/bf/Bulldog_inglese.jpg/800px-Bulldog_inglese.jpg" },
            { "pug", "https://cdn.britannica.com/34/233234-050-1649BFA9/Pug-dog.jpg" },
            { "yorkshire terrier", "https://cdn05.zipify.com/TNPDGbG-XijYAsfKvHkKwL8v_oc=/fit-in/3840x0/fdc57f66415e4ea8867b548377cbcb7e/1.jpeg" }
        };

        private readonly string defaultImageUrl = "https://via.placeholder.com/150";
        
        private string userName;
        private int roleID;
        private int userID;

        public RecommendDogForm(string userName, int roleID, int userID)
        {
            InitializeComponent();
            LoadDatabase();
            PopulateBreedComboBox();
            PopulateSizeComboBox();

            this.userID = userID;
            this.roleID = roleID;
            this.userName = userName;
        }

        private void LoadDatabase()
        {
            try
            {
                string query = "SELECT Breed, Age, Size, Description FROM Dogs";

                using (OleDbConnection conn = new OleDbConnection(myDatabase))
                {
                    conn.Open();
                    OleDbDataAdapter adapter = new OleDbDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    dgvPets.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading data: {ex.Message}", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void PopulateBreedComboBox()
        {
            try
            {
                using (OleDbConnection conn = new OleDbConnection(myDatabase))
                {
                    conn.Open();
                    string query = "SELECT DISTINCT Breed FROM Dogs";
                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    using (OleDbDataReader reader = cmd.ExecuteReader())
                    {
                        cmbBreed.Items.Clear();
                        cmbBreed.Items.Add("All Breeds");
                        while (reader.Read())
                        {
                            cmbBreed.Items.Add(reader["Breed"].ToString());
                        }
                    }
                }
                cmbBreed.SelectedIndex = 0; 
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading breeds: {ex.Message}", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void PopulateSizeComboBox()
        {
            try
            {
                using (OleDbConnection conn = new OleDbConnection(myDatabase))
                {
                    conn.Open();
                    string query = "SELECT DISTINCT Size FROM Dogs";
                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    using (OleDbDataReader reader = cmd.ExecuteReader())
                    {
                        cmbSize.Items.Clear();
                        cmbSize.Items.Add("All Sizes");
                        while (reader.Read())
                        {
                            cmbSize.Items.Add(reader["Size"].ToString());
                        }
                    }
                }
                cmbSize.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading sizes: {ex.Message}", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private DataTable GetRecommendedDogs(string breed, int age, string size)
        {
            DataTable dt = new DataTable();

            try
            {
                using (OleDbConnection conn = new OleDbConnection(myDatabase))
                {
                    conn.Open();

                    var query = @"SELECT Breed, Age, Size, Description 
                                  FROM Dogs 
                                  WHERE (Breed LIKE ? OR ? = 'All Breeds') 
                                  AND (Age = ? OR ? = -1) 
                                  AND (Size = ? OR ? = 'All Sizes')";

                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("?", breed == "All Breeds" ? "All Breeds" : "%" + breed + "%");
                        cmd.Parameters.AddWithValue("?", breed == "All Breeds" ? "All Breeds" : breed);
                        cmd.Parameters.AddWithValue("?", age > 0 ? age : -1);
                        cmd.Parameters.AddWithValue("?", age > 0 ? age : -1);
                        cmd.Parameters.AddWithValue("?", size == "All Sizes" ? "All Sizes" : size);
                        cmd.Parameters.AddWithValue("?", size == "All Sizes" ? "All Sizes" : size);

                        using (OleDbDataAdapter adapter = new OleDbDataAdapter(cmd))
                        {
                            adapter.Fill(dt);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error occurred: {ex.Message}", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return dt;
        }



        private void dgvPets_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow selectedRow = dgvPets.Rows[e.RowIndex];

                if (selectedRow.Cells["Breed"]?.Value != null)
                {
                    string breed = selectedRow.Cells["Breed"].Value.ToString().Trim().ToLower();

                    try
                    {
                        if (breeds.TryGetValue(breed, out string imageUrl))
                        {
                            pbPets.Load(imageUrl);
                        }
                        else
                        {
                            pbPets.Load(defaultImageUrl); 
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Failed to load image: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        pbPets.Image = null;
                    }
                }
            }
        }

        private void btnRecommend_Click_1(object sender, EventArgs e)
        {
            try
            {
                string breed = cmbBreed.SelectedItem?.ToString();
                int age = (int)numAge.Value;
                string size = cmbSize.SelectedItem?.ToString();

                DataTable recommendedDogs = GetRecommendedDogs(breed, age, size);

                if (recommendedDogs.Rows.Count > 0)
                {
                    dgvPets.DataSource = recommendedDogs;
                }
                else
                {
                    MessageBox.Show("No matches found based on your preferences.", "No Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    dgvPets.DataSource = null;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
            DashboardForm df = new DashboardForm(userName, roleID, userID);
            df.ShowDialog();
        }
    }
}
