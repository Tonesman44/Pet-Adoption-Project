﻿using System;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;

namespace PetApplicationProject
{
    public partial class AccountManagementForm : Form
    {
        string myDatabase = "Provider=Microsoft.ACE.OLEDB.12.0; Data Source=PetApplicationDB.accdb";
        private int userID;
        private int roleID;
        private string userName;
        public AccountManagementForm(string userName, int roleID, int userID)
        {
            InitializeComponent();
            LoadData();
            this.userName = userName;
            this.userID = userID;
            this.roleID = roleID;
        }

        private void LoadData()
        {
            string query = "SELECT * FROM Users";

            try
            {
                using (OleDbConnection conn = new OleDbConnection(myDatabase))
                {
                    conn.Open();
                    OleDbDataAdapter adapter = new OleDbDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    dgvPets.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error occurred: {ex.Message}", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dgvPets_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvPets.CurrentRow != null && dgvPets.CurrentRow.Index >= 0)
            {
                txtUserName.Text = dgvPets.CurrentRow.Cells["UserName"].Value?.ToString();
                txtFirstName.Text = dgvPets.CurrentRow.Cells["FirstName"].Value?.ToString();
                txtLastName.Text = dgvPets.CurrentRow.Cells["LastName"].Value?.ToString();
                txtEmail.Text = dgvPets.CurrentRow.Cells["Email"].Value?.ToString();
                txtPassword.Text = dgvPets.CurrentRow.Cells["Password"].Value?.ToString();
            }
        }
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (dgvPets.CurrentRow == null || dgvPets.CurrentRow.Index < 0)
            {
                MessageBox.Show("Please select a user to update.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrEmpty(txtUserName.Text) || string.IsNullOrEmpty(txtFirstName.Text) ||
                string.IsNullOrEmpty(txtLastName.Text) || string.IsNullOrEmpty(txtEmail.Text) ||
                string.IsNullOrEmpty(txtPassword.Text))
            {
                MessageBox.Show("Please fill in all fields before saving.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string query = "UPDATE Users SET [UserName] = ?, [FirstName] = ?, [LastName] = ?, [Email] = ?, [Password] = ? WHERE [UserID] = ?";

            try
            {
                using (OleDbConnection conn = new OleDbConnection(myDatabase))
                {
                    conn.Open();
                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@UserName", txtUserName.Text);
                        cmd.Parameters.AddWithValue("@FirstName", txtFirstName.Text);
                        cmd.Parameters.AddWithValue("@LastName", txtLastName.Text);
                        cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
                        cmd.Parameters.AddWithValue("@Password", txtPassword.Text);
                        cmd.Parameters.AddWithValue("@UserID", dgvPets.CurrentRow.Cells["UserID"].Value);

                        cmd.ExecuteNonQuery();
                        MessageBox.Show("User details updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        LoadData();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating user: {ex.Message}", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            Clear();
        }

        private void Clear()
        {
            txtUserName.Clear();
            txtFirstName.Clear();
            txtLastName.Clear();
            txtEmail.Clear();
            txtPassword.Clear();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
            DashboardForm df = new DashboardForm(userName, roleID, userID);
            df.ShowDialog();
        }
    }
}

