﻿using System;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;

namespace PetApplicationProject
{
    public partial class DashboardForm : Form
    {
        private string userName;
        private int roleId;
        private int userId;


        public DashboardForm(string userName, int roleId, int userId)
        {
            InitializeComponent();

            this.userName = userName;
            this.roleId = roleId;
            this.userId = userId;
        }

        string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0; Data Source = PetApplicationDB.accdb";

        private void DashboardForm_Load(object sender, EventArgs e)
        {
            lblUser.Text = string.IsNullOrWhiteSpace(userName) ? "Welcome!" : $"Welcome {userName}!";
            btnAdd.Visible = (roleId == 2);
            btnAdminPanel.Visible = (roleId == 2);

            LoadDogData();
        }

        private void LoadDogData()
        {
            string query = "SELECT DogID, Name, Breed, Age, Gender, Size, Description FROM Dogs";

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    OleDbDataAdapter adapter = new OleDbDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    dgvDogs.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error occurred while loading data: {ex.Message}");
                }
            }
        }

        private void btnSettings_Click(object sender, EventArgs e)
        {
            AccountManagementForm ac = new AccountManagementForm(userName, roleId, userId);
            this.Hide();
            ac.Show();
        }

        private void btnApply_Click(object sender, EventArgs e)
        {
            AdoptionApplicationForm ap = new AdoptionApplicationForm(userName, roleId, userId);
            this.Hide();
            ap.Show();
        }

        private void btnProfile_Click(object sender, EventArgs e)
        {
            DogProfileForm dogProfileForm = new DogProfileForm(userName, roleId, userId);
            this.Hide();
            dogProfileForm.Show();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            DogBrowseForm searchForm = new DogBrowseForm(userName, roleId, userId);
            this.Hide();
            searchForm.Show();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            DogManagementForm dogManagement = new DogManagementForm(userName, roleId, userId);
            this.Hide();
            dogManagement.Show();
        }

        private void btnAdminPanel_Click(object sender, EventArgs e)
        {
            AdminPanelForm adminPanelForm = new AdminPanelForm(userName, roleId, userId);
            this.Hide();
            adminPanelForm.Show();
        }

        private void btnData_Click(object sender, EventArgs e)
        {
            AnalyticsForm data = new AnalyticsForm(userName, roleId, userId);
            this.Hide();
            data.Show();
        }

        private void btnRecommendation_Click(object sender, EventArgs e)
        {
            RecommendDogForm recommendDogForm = new RecommendDogForm(userName, roleId, userId);
            this.Hide();
            recommendDogForm.Show();
        }
    }
}
