﻿namespace PetApplicationProject
{
    partial class Startup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnNext = new Button();
            dgvPets = new DataGridView();
            btnExit = new Button();
            label1 = new Label();
            label2 = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvPets).BeginInit();
            SuspendLayout();
            // 
            // btnNext
            // 
            btnNext.BackColor = Color.Chartreuse;
            btnNext.Location = new Point(207, 533);
            btnNext.Margin = new Padding(4, 3, 4, 3);
            btnNext.Name = "btnNext";
            btnNext.Size = new Size(179, 55);
            btnNext.TabIndex = 0;
            btnNext.Text = "Next";
            btnNext.UseVisualStyleBackColor = false;
            btnNext.Click += btnNext_Click;
            // 
            // dgvPets
            // 
            dgvPets.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvPets.Location = new Point(165, 154);
            dgvPets.Margin = new Padding(4, 5, 4, 5);
            dgvPets.Name = "dgvPets";
            dgvPets.RowHeadersWidth = 62;
            dgvPets.Size = new Size(594, 357);
            dgvPets.TabIndex = 1;
            // 
            // btnExit
            // 
            btnExit.BackColor = Color.IndianRed;
            btnExit.Location = new Point(513, 533);
            btnExit.Margin = new Padding(4, 5, 4, 5);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(186, 55);
            btnExit.TabIndex = 2;
            btnExit.Text = "Exit";
            btnExit.UseVisualStyleBackColor = false;
            btnExit.Click += btnExit_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 20F);
            label1.ForeColor = SystemColors.ButtonHighlight;
            label1.Location = new Point(102, 50);
            label1.Name = "label1";
            label1.Size = new Size(719, 54);
            label1.TabIndex = 3;
            label1.Text = "Welcome to Happy Tails Dog Adoption!";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 16F);
            label2.ForeColor = SystemColors.ButtonHighlight;
            label2.Location = new Point(190, 104);
            label2.Name = "label2";
            label2.Size = new Size(553, 45);
            label2.TabIndex = 4;
            label2.Text = "Click Next to either Login or Register!";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(947, 750);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btnExit);
            Controls.Add(dgvPets);
            Controls.Add(btnNext);
            Margin = new Padding(4, 5, 4, 5);
            Name = "Form1";
            Text = "Start";
            ((System.ComponentModel.ISupportInitialize)dgvPets).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnNext;
        private DataGridView dgvPets;
        private Button btnExit;
        private Label label1;
        private Label label2;
    }
}