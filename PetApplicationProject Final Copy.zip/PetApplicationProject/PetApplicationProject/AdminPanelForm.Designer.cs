﻿namespace PetApplicationProject
{
    partial class AdminPanelForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label2 = new Label();
            btnApprove = new Button();
            label4 = new Label();
            btnDeny = new Button();
            dgvApplications = new DataGridView();
            rtxtQuestionAfterCare = new RichTextBox();
            txtQuestionOwnedPets = new TextBox();
            txtQuestionAmountPets = new TextBox();
            txtQuestionLiving = new TextBox();
            txtQuestionChildren = new TextBox();
            label1 = new Label();
            label3 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            txtInput = new TextBox();
            label8 = new Label();
            groupBox1 = new GroupBox();
            groupBox2 = new GroupBox();
            btnSearch = new Button();
            btnReturn = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvApplications).BeginInit();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(546, 100);
            label2.Name = "label2";
            label2.Size = new Size(278, 50);
            label2.TabIndex = 1;
            label2.Text = "Adoption Requests Management:\n\n";
            // 
            // btnApprove
            // 
            btnApprove.Location = new Point(546, 479);
            btnApprove.Name = "btnApprove";
            btnApprove.Size = new Size(190, 71);
            btnApprove.TabIndex = 5;
            btnApprove.Text = "Approve";
            btnApprove.UseVisualStyleBackColor = true;
            btnApprove.Click += btnApprove_Click_1;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 24F);
            label4.Location = new Point(435, 9);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(293, 65);
            label4.TabIndex = 10;
            label4.Text = "Admin Panel";
            // 
            // btnDeny
            // 
            btnDeny.Location = new Point(765, 479);
            btnDeny.Name = "btnDeny";
            btnDeny.Size = new Size(187, 71);
            btnDeny.TabIndex = 4;
            btnDeny.Text = "Deny";
            btnDeny.UseVisualStyleBackColor = true;
            btnDeny.Click += btnDeny_Click_1;
            // 
            // dgvApplications
            // 
            dgvApplications.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvApplications.Location = new Point(546, 130);
            dgvApplications.Name = "dgvApplications";
            dgvApplications.RowHeadersWidth = 62;
            dgvApplications.Size = new Size(625, 325);
            dgvApplications.TabIndex = 5;
            // 
            // rtxtQuestionAfterCare
            // 
            rtxtQuestionAfterCare.Location = new Point(21, 233);
            rtxtQuestionAfterCare.Name = "rtxtQuestionAfterCare";
            rtxtQuestionAfterCare.Size = new Size(401, 73);
            rtxtQuestionAfterCare.TabIndex = 12;
            rtxtQuestionAfterCare.Text = "";
            // 
            // txtQuestionOwnedPets
            // 
            txtQuestionOwnedPets.Location = new Point(21, 70);
            txtQuestionOwnedPets.Name = "txtQuestionOwnedPets";
            txtQuestionOwnedPets.Size = new Size(174, 31);
            txtQuestionOwnedPets.TabIndex = 13;
            // 
            // txtQuestionAmountPets
            // 
            txtQuestionAmountPets.Location = new Point(233, 146);
            txtQuestionAmountPets.Name = "txtQuestionAmountPets";
            txtQuestionAmountPets.Size = new Size(189, 31);
            txtQuestionAmountPets.TabIndex = 14;
            // 
            // txtQuestionLiving
            // 
            txtQuestionLiving.Location = new Point(233, 70);
            txtQuestionLiving.Name = "txtQuestionLiving";
            txtQuestionLiving.Size = new Size(189, 31);
            txtQuestionLiving.TabIndex = 15;
            // 
            // txtQuestionChildren
            // 
            txtQuestionChildren.Location = new Point(21, 146);
            txtQuestionChildren.Name = "txtQuestionChildren";
            txtQuestionChildren.Size = new Size(174, 31);
            txtQuestionChildren.TabIndex = 16;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(21, 42);
            label1.Name = "label1";
            label1.Size = new Size(103, 25);
            label1.TabIndex = 17;
            label1.Text = "Question 1:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(233, 42);
            label3.Name = "label3";
            label3.Size = new Size(103, 25);
            label3.TabIndex = 18;
            label3.Text = "Question 2:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(21, 118);
            label5.Name = "label5";
            label5.Size = new Size(103, 25);
            label5.TabIndex = 19;
            label5.Text = "Question 3:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(233, 118);
            label6.Name = "label6";
            label6.Size = new Size(103, 25);
            label6.TabIndex = 20;
            label6.Text = "Question 4:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(20, 205);
            label7.Name = "label7";
            label7.Size = new Size(103, 25);
            label7.TabIndex = 21;
            label7.Text = "Question 5:";
            // 
            // txtInput
            // 
            txtInput.Location = new Point(20, 58);
            txtInput.Name = "txtInput";
            txtInput.Size = new Size(201, 31);
            txtInput.TabIndex = 22;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(20, 30);
            label8.Name = "label8";
            label8.Size = new Size(201, 25);
            label8.TabIndex = 23;
            label8.Text = "Enter the ID of the User:";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(rtxtQuestionAfterCare);
            groupBox1.Controls.Add(txtQuestionOwnedPets);
            groupBox1.Controls.Add(txtQuestionAmountPets);
            groupBox1.Controls.Add(label7);
            groupBox1.Controls.Add(txtQuestionLiving);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(txtQuestionChildren);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(label3);
            groupBox1.Location = new Point(53, 225);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(450, 325);
            groupBox1.TabIndex = 24;
            groupBox1.TabStop = false;
            groupBox1.Text = "Responses:";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(btnSearch);
            groupBox2.Controls.Add(txtInput);
            groupBox2.Controls.Add(label8);
            groupBox2.Location = new Point(53, 100);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(450, 110);
            groupBox2.TabIndex = 25;
            groupBox2.TabStop = false;
            groupBox2.Text = "Search:";
            // 
            // btnSearch
            // 
            btnSearch.Location = new Point(268, 46);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(143, 43);
            btnSearch.TabIndex = 24;
            btnSearch.Text = "Search";
            btnSearch.UseVisualStyleBackColor = true;
            btnSearch.Click += btnSearch_Click;
            // 
            // btnReturn
            // 
            btnReturn.Location = new Point(984, 479);
            btnReturn.Name = "btnReturn";
            btnReturn.Size = new Size(187, 71);
            btnReturn.TabIndex = 26;
            btnReturn.Text = "Return to Menu";
            btnReturn.UseVisualStyleBackColor = true;
            btnReturn.Click += btnReturn_Click;
            // 
            // AdminPanelForm
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(1195, 587);
            Controls.Add(btnReturn);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(btnDeny);
            Controls.Add(dgvApplications);
            Controls.Add(label4);
            Controls.Add(btnApprove);
            Controls.Add(label2);
            Name = "AdminPanelForm";
            Text = "AdminPanelForm";
            ((System.ComponentModel.ISupportInitialize)dgvApplications).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label2;
        private Button btnApprove;
        private Label label4;
        private Button btnDeny;
        private DataGridView dgvApplications;
        private RichTextBox rtxtQuestionAfterCare;
        private TextBox txtQuestionOwnedPets;
        private TextBox txtQuestionAmountPets;
        private TextBox txtQuestionLiving;
        private TextBox txtQuestionChildren;
        private Label label1;
        private Label label3;
        private Label label5;
        private Label label6;
        private Label label7;
        private TextBox txtInput;
        private Label label8;
        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private Button btnReturn;
        private Button btnSearch;
    }
}