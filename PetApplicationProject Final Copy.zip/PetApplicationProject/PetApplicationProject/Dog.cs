﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PetApplicationProject
{
    public class Dog
    {
        public int DogID { get; set; }
        public string Name { get; set; }
        public string Breed { get; set; }
        public int Age { get; set; }
        public string Gender { get; set; }
        public string Size { get; set; }
        public string Description { get; set; }
        public int ShelterEmployeeID { get; set; }

        public string GetDescription()
        {
            return $"{Name} is a {Age}-year-old {Gender} {Breed} of {Size} size.";
        }
    }
}